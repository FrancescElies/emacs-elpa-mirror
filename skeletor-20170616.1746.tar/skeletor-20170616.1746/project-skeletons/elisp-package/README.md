# __PROJECT-NAME__

## Summary

__DESCRIPTION__

## Installing

You will need Emacs 24+, `make` and [Cask](https://github.com/cask/cask) to
build the project.

    cd __PROJECT-NAME__
    make && make install


## Contributing

Yes, please do! See [CONTRIBUTING][] for guidelines.

## License

See [COPYING][]. Copyright (c) __YEAR__ __USER-NAME__.


[CONTRIBUTING]: ./CONTRIBUTING.md
[COPYING]: ./__LICENSE-FILE-NAME__
